---
name: Bug Fix
about: Fix for a driver issue
title: "Fix | "

---

## Problem description
<!--- Provide full details of the problem if no corresponding GitHub issue exists. --->

### Fixes existing GitHub issue
<!--- Provide link to GitHub issue above. --->

## Fix Description
<!--- Briefly describe the fix implementation. --->

## New Public APIs
<!--- List any new public APIs added with this Fix. --->

