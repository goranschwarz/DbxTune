update customers_demo
set cust_address_ntab = cust_address_ntab multiset union cust_address_ntab
