(select 'a' obj, 'b' link from dual) union all
(select 'a', 'c' from dual) union all
(select      'c', 'd' from dual) union all
(select           'd', 'c' from dual) union all
(select           'd', 'e' from dual) union all
(select                'e', 'e' from dual)

