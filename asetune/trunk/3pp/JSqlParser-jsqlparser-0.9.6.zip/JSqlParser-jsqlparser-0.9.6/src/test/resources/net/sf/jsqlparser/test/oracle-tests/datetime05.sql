select date '1900-01-01' from dual
