select cast(powermultiset(cust_address_ntab)
as cust_address_tab_tab_typ)
from customers_demo
