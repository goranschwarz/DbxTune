select * from t1 
join t2 tt2 using(c)
join t3 tt3 using(d)
join t3 using(d)

