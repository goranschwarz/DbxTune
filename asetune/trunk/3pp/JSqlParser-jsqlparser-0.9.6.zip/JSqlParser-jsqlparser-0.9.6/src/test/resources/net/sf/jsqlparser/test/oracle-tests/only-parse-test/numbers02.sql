select 25
, 1.-+.5
, 1.+.5
, 1.+.5D
, 1.+.5DM
, 1.D
, 1.M
, .5M
, .5DM
from dual

