select
  'hello'
, 'oracle.dbs'
, 'jackie''s raincoat'
, '09-mar-98'
, ''
, ''''
, q'!name like '%dbms_%%'!'
, q'<'so,' she said, 'it's finished.'>'
, q'{select * from employees where last_name = 'smith'}'
, q'"name like '['"'
, n'nchar literal'
from dual

