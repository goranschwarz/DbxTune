select * from (( select * from dual)) a

