//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by sspi.rc
//
#define DAO35                           1
#define IDS_BUFFERTOOSMALL              1
#define IDS_ENDOFCURSOR                 2
#define IDS_SILENTCANCEL                3
#define IDS_RECORDDELETED               4
#define IDS_ROWTOOSHORT                 5
#define IDS_BADBINDINFO                 6
#define IDS_COLUMNUNAVAILABLE           7

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
